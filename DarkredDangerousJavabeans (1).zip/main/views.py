from django.shortcuts import render
from django.utils.safestring import mark_safe
import json

# Create your views here.
def home(request):
    return render(request, 'main/index.html')
def wheel(request):
    return render(request, 'main/teams/AchiliesWheel/index.html')
def rttk(request):
  return render(request, 'main/teams/RTTK/index.html')
def vert(request):
    return render(request, 'main/teams/Vertigo/index.html')
def rip(request):
    return render(request, 'main/teams/RIP/index.html')