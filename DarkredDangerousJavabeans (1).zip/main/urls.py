from django.conf.urls import url
from django.contrib import admin
from main import views

urlpatterns = [
  url(r'^admin/', admin.site.urls),
  url(r'^$', views.home, name='home'),
  url(r'15095',views.rip,name='rip'),
  url(r'5452',views.rttk,name='rttk'),
  url(r'6287',views.vert,name='vert'),
  url(r'12359',views.wheel,name='wheel')
]
